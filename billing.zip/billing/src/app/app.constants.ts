const employee = [
    
    {
        'name' : 'Karthik',
        'id'   : '111'
    },
    {
        'name' : 'Ramu',
        'id'   : '111'
    },
    {
        'name' : 'Rajesh',
        'id'   : '111'
    },
    {
        'name' : 'Raveendran',
        'id'   : '111'
    },
    {
        'name' : 'Rajkumar',
        'id'   : '111'
    }

];

const columnsData = {
    soName: 'SO Name'
    ,   soStartDate : 'SO Start Date'
    ,   soEndDate : 'SO End date'
    ,   soAmount : 'SO Amount'
    ,   totalSoAmount : 'Total PO Amount'
    ,   soSigned : 'SO Signed'
    ,   empId : 'Emp.ID'
    ,   band : 'Band'     
    ,   empName : 'Employee Name'
    ,   cbaStaffId : 'CBA Staff ID'
    ,   location : 'Location'
    ,   totalPoAmount : 'Total PO Amount'
    ,   billingFrom : 'Billing From'
    ,   billingTo : 'Billing to'
    /*,   percentageOfAssignation: 'Percentage of the assignation'
    ,   leaveInDays : 'Leave in Days'
    ,   gfte : 'Gross fulltime Equivalent (GFTE) in Days'
    ,   afte : 'Available fulltime Equivalent (AFTE) in Days'
    ,   bfte : 'Billed fulltime Equivalent (BFTE) in Days'
    ,   brqId : 'BRQ ID'
    ,   roleCode : 'Role Code'
    ,   designation  : 'Designation'
    ,   rate : 'Rate (Per Day)'
    ,   billAmount : 'Bill Amount'
    ,   billAmountGst : 'Bill Amount with 10% GST'
    ,   poNumber : 'PO No'
    ,   unbilledReason: 'Unbilled/Partially Billed Reason'
    ,   GM : 'GM'
    ,   EGM : 'EGM'
    ,   clientSegment : 'Client Segment'
    ,   hclSegment : 'HCL Segment'
    ,   soType : 'SO Type'
    ,   newRate : 'NEW /OLD RATE PM REMARK'
    ,   cbaSpoc : 'CBA Spoc'
    ,   escalationContact : 'Escalation contact'
    ,   deliveryType : 'Delivery type'
    ,   billingStatus : 'Billing Status'
    ,   projectCode : 'Project Code'
    ,   projectName : 'Project Name'
    ,   projectCategory : 'Project Category'
    ,   pmoSpoc : 'PMO SPOC'
    ,   amountUSD : 'Amount in USD'
    ,   pmName : ' Project Manager Name'*/
};

export const appConfig = {
    'employee' : employee
    ,   'columnsData' : columnsData
};