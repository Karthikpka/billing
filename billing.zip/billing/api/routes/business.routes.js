const express = require('express');
const app = express();
const businessRoutes = express.Router();

// Require Business model in our routes module
let Business = require('../models/Business');
//let Billing = require('../models/Billing');

// Defined store route
businessRoutes.route('/add').post(function (req, res) {
  let business = new Business(req.body);
  business.save()
    .then(business => {
      res.status(200).json({'business': 'business in added successfully'});
    })
    .catch(err => {
    res.status(400).send("unable to save to database" + JSON.stringify(req.body));
    });
});

businessRoutes.route('/addBilling').post(function (req, res) {
    
  //let business = new Business(req.body);
    
 /*  business.save()
    .then(business => {
      res.status(200).json({'business': 'billing added successfully'});
    })
    .catch(err => {
    res.status(400).send("unable to save to database" + JSON.stringify(req.body));
    });*/
    
   for(let i =0; i < req.body.length; i++) {
      let business = new Business(req.body[i]);
       business.save().catch(err => {
            res.status(400).send("unable to save to database" + JSON.stringify(req.body));
       });       
   }
    
    res.status(200).json({'business': 'billing added successfully'});
    
});

// Defined store route
businessRoutes.route('/getBilling').get(function (req, res) {
  console.log(req);

    Business.find(
      {
        $and: [
            { $or: [{empID: req}] }
        ]
    }   
    , function (err, data){
        console.log(data);
        if(err){
          console.log(err);
        }
        else {
          console.log(data);
          res.json(data);
        }
    });
});

// Defined store route
businessRoutes.route('/getEmployees').get(function (req, res) {
     Business.aggregate([
        {
            $group: {
                _id: { empId: '$empId', empName: "$empName"}
            }
        }
    ], function (err, result) {
        if (err) {
            next(err);
        } else {
            res.json(result);
        }
    });
});




// Defined get data(index or listing) route
businessRoutes.route('/').get(function (req, res) {
    Business.find(function (err, businesses){
    if(err){
      console.log(err);
    }
    else {
      res.json(businesses);
    }
  });
});

// Defined edit route
businessRoutes.route('/edit/:id').get(function (req, res) {
  let id = req.params.id;
  Business.findById(id, function (err, business){
      res.json(business);
  });
});

//  Defined update route
businessRoutes.route('/update/:id').post(function (req, res) {
    Business.findById(req.params.id, function(err, next, business) {
    if (!business)
      return next(new Error('Could not load Document'));
    else {
        business.person_name = req.body.person_name;
        business.business_name = req.body.business_name;
        business.business_gst_number = req.body.business_gst_number;

        business.save().then(business => {
          res.json('Update complete');
      })
      .catch(err => {
            res.status(400).send("unable to update the database");
      });
    }
  });
});

// Defined delete | remove | destroy route
businessRoutes.route('/delete/:id').get(function (req, res) {
    Business.findByIdAndRemove({_id: req.params.id}, function(err, business){
        if(err) res.json(err);
        else res.json('Successfully removed');
    });
});

module.exports = businessRoutes;