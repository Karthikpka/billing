import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BsDatepickerModule, BsDropdownModule, PaginationModule  } from 'ngx-bootstrap'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BusinessService } from './business.service';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BillingUploadComponent } from './billing-upload/billing-upload.component';
import { BillingViewComponent } from './billing-view/billing-view.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { TestComponent } from './test/test.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    BillingUploadComponent,
    BillingViewComponent,
    PageNotFoundComponent,
    TestComponent,
    HomeComponent    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BsDatepickerModule.forRoot(),
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [BusinessService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
