import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingUploadComponent } from './billing-upload.component';

describe('BillingUploadComponent', () => {
  let component: BillingUploadComponent;
  let fixture: ComponentFixture<BillingUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillingUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
