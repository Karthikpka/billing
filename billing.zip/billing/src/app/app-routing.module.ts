import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BillingUploadComponent } from './billing-upload/billing-upload.component';
import { BillingViewComponent } from './billing-view/billing-view.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [];

const appRoutes: Routes = [
  {
    path: 'upload',
    component: BillingUploadComponent,
    data: { title: 'Upload Billing' }
  },
  {
    path: 'view',
    component: BillingViewComponent,
    data: { title: 'View Billing' }
  },
  {
    path: 'home',
    component: HomeComponent,
    data: { title: 'Dashboard' }
  },
  { path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
