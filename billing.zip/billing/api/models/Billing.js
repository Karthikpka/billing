const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Billing = new Schema({
  empId: {
    type: String
  },
  empName: {
    type: String
  },
  soStartDate: {
    type: String
  },
  soEndDate: {
    type: String
  },
  totalPoAmount: {
    type: String
  },
  billingFrom: {
    type: String
  },
  billingTo: {
    type: String
  },
  leaveInDays: {
    type: String
  }
},{
    collection: 'billingData'
});

module.exports = mongoose.model('billingData', Billing);