import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import { BusinessService } from '../business.service';
import { appConfig } from '../app.constants';

@Component({
  selector: 'app-billing-upload',
  templateUrl: './billing-upload.component.html',
  styleUrls: ['./billing-upload.component.scss']
})

export class BillingUploadComponent implements OnInit {
    sheetData:any;
    columnsData:any;
    errorList:any=[];
    billingData:any;
 
  constructor(private bs: BusinessService) { }

  ngOnInit() {
    this.columnsData=appConfig.columnsData;
  }
  
  fileEventHandler(fileInput) {
    
    const target : DataTransfer = <DataTransfer>(fileInput.target);
    
    if(target.files.length) {
        let file = fileInput.target.files[0];
        const reader: FileReader = new FileReader();
        
        reader.onload = (e: any) => {
            const bstr: string = e.target.result;
            
            try {
                const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary', raw : true});
                const wsname: string = wb.SheetNames[0];
                const ws: XLSX.WorkSheet = wb.Sheets[wsname];
                this.sheetData = (XLSX.utils.sheet_to_json(ws));
            }
            catch(err) {
                this.errorList.push('File format issue');
            }
        }   
        
        reader.readAsBinaryString(target.files[0]);
        
        let self = this;
        setTimeout(function(){            
            //console.log(self.sheetData);
            //console.log(self.errorList);
        }, 1000);
    }
  }
  
  previewData() {    
    this.billingData=[];
    
    for(let i = 0; i < this.sheetData.length; i++) {
                
        let obj:any={
            soName: null
            ,   soStartDate : null
            ,   soEndDate : null
            ,   soAmount : null
            ,   totalSoAmount : null
            ,   soSigned : null
            ,   empId : null
            ,   band : null     
            ,   empName : null
            ,   cbaStaffId : null
            ,   location : null
            ,   totalPoAmount : null
            ,   billingFrom : null
            ,   billingTo : null
            /*,   percentageOfAssignation: null
            ,   leaveInDays : null
            ,   gfte : null
            ,   afte : null
            ,   bfte : null
            ,   brqId : null
            ,   roleCode : null
            ,   designation  : null
            ,   rate : null
            ,   billAmount : null
            ,   billAmountGst : null
            ,   poNumber : null
            ,   unbilledReason: null
            ,   GM : null
            ,   EGM : null
            ,   clientSegment : null
            ,   hclSegment : null
            ,   soType : null
            ,   newRate : null
            ,   cbaSpoc : null
            ,   escalationContact : null
            ,   deliveryType : null
            ,   billingStatus : null
            ,   projectCode : null
            ,   projectName : null
            ,   projectCategory : null
            ,   pmoSpoc : null
            ,   amountUSD : null
            ,   pmName : null*/
        }; 
        
        for(let sheetData in this.sheetData[i]) {            
            for(let key in this.columnsData) {            
                if(sheetData.trim() === this.columnsData[key].trim()) {
                    //console.log(sheetData.trim()+'--'+this.columnsData[key].trim());
                    obj[key] = this.sheetData[i][sheetData].trim()
                }
            }        
        }    
        
        this.billingData.push(obj);        
    }

    //console.log(this.columnsData);
    
    //console.log(this.billingData);
    
    this.bs.addBillingData(this.billingData);
    
     //this.bs.addBusiness(person_name, busines_name, business_gst_number)
  }
}
