const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for Business
/*let Business = new Schema({
  person_name: {
    type: String
  },
  business_name: {
    type: String
  },
  business_gst_number: {
    type: Number
  }
},{
    collection: 'business'
});*/

let Business = new Schema({
  empId: {
    type: String
  },
  empName: {
    type: String
  },
  soStartDate: {
    type: String
  },
  soEndDate: {
    type: String
  },
  totalPoAmount: {
    type: String
  },
  billingFrom: {
    type: String
  },
  billingTo: {
    type: String
  },
  leaveInDays: {
    type: String
  }
},{
    collection: 'billingData'
});

module.exports = mongoose.model('billingData', Business);

//module.exports = mongoose.model('Business', Business);