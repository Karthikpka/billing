import { Component, OnInit } from '@angular/core';
import { appConfig } from '../app.constants';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BusinessService } from '../business.service';

@Component({
  selector: 'app-billing-view',
  templateUrl: './billing-view.component.html',
  styleUrls: ['./billing-view.component.scss']
})
export class BillingViewComponent implements OnInit {
  viewForm: FormGroup;
  employees;
  billingData:any;
  
  constructor(private bs: BusinessService) {
      
  }

  ngOnInit() { 
    //this.getEmployees();
    
    this.viewForm = new FormGroup({
        empId : new FormControl('', Validators.required),
        startDate : new FormControl('', Validators.required),
        endDate : new FormControl('', Validators.required)
    });
  }

  getEmployees() {
    this.bs.getEmployees().subscribe(data => {
      this.employees = data;
    });    
  }
  
  viewData() {    
    console.log(this.viewForm.get('startDate').value);
    console.log(this.viewForm.get('endDate').value);
    console.log(this.viewForm.get('empId').value);

    let empId = this.viewForm.get('empId').value;

    this.bs.getBilling(empId).subscribe(data => {
      this.billingData = data;
    });        
  }
}
