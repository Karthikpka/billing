const express = require('express');
const app = express();
const billingRoutes = express.Router();

// Require Billing model in our routes module
let Billing = require('../models/Billing');

billingRoutes.route('/addBilling').post(function (req, res) {
    
   for(let i =0; i < req.body.length; i++) {
      let billing = new Billing(req.body[i]);
       
       billing.save().catch(err => {
            res.status(400).send("unable to save to database" + JSON.stringify(req.body));
       });       
   }
    
    res.status(200).json({'billing': 'billing added successfully'});    
});

// Defined store route
billingRoutes.route('/getBilling').get(function (req,res) {
    Billing.find(function (err, res){
        if(err){
          console.log(err);
        }
        else {
          res.json(res);
        }
    });
});

module.exports = billingRoutes;